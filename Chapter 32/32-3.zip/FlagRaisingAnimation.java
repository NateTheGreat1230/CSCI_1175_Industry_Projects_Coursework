package com.calc.calculator;

import javafx.animation.PathTransition;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.util.Duration;

public class FlagRaisingAnimation extends Application {
    	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) {
		new Thread(() -> { // lambda expression
            Pane pane = new Pane();
            ImageView imageView = new ImageView("/home/natethegreat/IdeaProjects/Calculator/src/main/java/com/calc/calculator/image/us.gif");
            pane.getChildren().add(imageView);
			PathTransition pt = new PathTransition(Duration.millis(10000), new Line(100, 200, 100, 0), imageView); pt.setCycleCount(5);
		    //pt.play(); // Start animation
            Scene scene = new Scene(pane, 250, 200);
            primaryStage.setTitle("FlagRisingAnimation"); // Set the stage title
            primaryStage.setScene(scene); // Place the scene in the stage
            primaryStage.show(); // Display the stage
		}).start();
	}
    public static void main(String[] args) {
        Application.launch(args);
    }
}