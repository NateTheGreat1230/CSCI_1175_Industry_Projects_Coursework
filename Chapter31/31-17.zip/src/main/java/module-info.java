module com.example.chapter31_exercises {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.chapter31_exercises to javafx.fxml;
    exports com.example.chapter31_exercises;
}