package com.example.chapter31_exercises;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Controller31_17 {
    public TextField amountTF;
    public TextField interestTF;
    public TextField yearsTF;
    public TextField futureTF;

    @FXML
    protected void Calculate() {
        double investmentAmount = Double.parseDouble(amountTF.getText());
        double years = Double.parseDouble(yearsTF.getText());
        double interestRate = Double.parseDouble(interestTF.getText());
        double futureValue = investmentAmount*(1+(interestRate/100*years));
        futureTF.setText(String.valueOf(futureValue));
    }
    @FXML
    protected void Exit() {
        Stage stage = (Stage) futureTF.getScene().getWindow();
        stage.close();
    }
}
