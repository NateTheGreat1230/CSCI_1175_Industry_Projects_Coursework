package com.calc.calculator;// Exercise31_01Server.java: The server can communicate with
// multiple clients concurrently using the multiple threads
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class Exercise33_01Server extends Application {
  // Text area for displaying contents
  private TextArea ta = new TextArea();
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) throws IOException {
    ServerSocket serverSocket = new ServerSocket(8000);
    ta.setWrapText(true);
    // Create a scene and place it in the stage
    Scene scene = new Scene(new ScrollPane(ta), 400, 200);
    primaryStage.setTitle("Exercise31_01Server"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
    new Thread(() -> {
      try {
        Socket socket = serverSocket.accept();
        DataInputStream in = new DataInputStream(socket.getInputStream());
        DataOutputStream out = new DataOutputStream(socket.getOutputStream());
      while (true) {
        double interest = in.readDouble();
        double years = in.readDouble();
        double amount = in.readDouble();
        Loan loan = new Loan(interest, (int) years, amount);
        double monthly = loan.getMonthlyPayment();
        double total = loan.getTotalPayment();
        out.writeDouble(monthly);
        out.writeDouble(total);
        out.flush();
        Platform.runLater(() -> {
          ta.appendText("Recieved interest: " + interest + '\n');
          ta.appendText("Recieved amount: " + amount + '\n');
          ta.appendText("Interest: " + interest + "\n");
          ta.appendText("Years: " + years + "\n");
          ta.appendText("Amount: " + amount + "\n");
          ta.appendText("Monthly payment: " + monthly + "\n");
          ta.appendText("Total payment: " + total + "\n");
        });
      }
      } catch(IOException ex) {
        System.err.println(ex);
      }
    }).start();
  }
  public static void main(String[] args) {
    launch(args);
  }
}