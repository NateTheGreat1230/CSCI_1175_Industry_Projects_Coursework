package com.calc.calculator;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.atomic.AtomicReference;

public class Exercise33_09Server extends Application {
  private TextArea taServer = new TextArea();
  private TextArea taClient = new TextArea();
  DataInputStream in;
  DataOutputStream out;
 
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) throws IOException {
    ServerSocket serverSocket = new ServerSocket(8000);
    taServer.setWrapText(true);
    taClient.setWrapText(true);
    taClient.setDisable(true);

    BorderPane pane1 = new BorderPane();
    pane1.setTop(new Label("History"));
    pane1.setCenter(new ScrollPane(taClient));
    BorderPane pane2 = new BorderPane();
    pane2.setTop(new Label("New Message"));
    pane2.setCenter(new ScrollPane(taServer));
    
    VBox vBox = new VBox(5);
    vBox.getChildren().addAll(pane1, pane2);

    // Create a scene and place it in the stage
    Scene scene = new Scene(vBox, 200, 200);
    primaryStage.setTitle("Exercise31_09Server"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    taServer.setOnKeyPressed(e -> {
      if (e.getCode() == KeyCode.ENTER) {
      try {
        String MSG = null;
        MSG = taServer.getText().trim();
        out.writeUTF(MSG);
        out.flush();
        taClient.appendText("S: " + MSG + '\n');
      } catch (IOException ex) {
        System.err.println(ex);
      }
      taServer.setText("");
      }
    });

    new Thread(() -> {
      try {
        Socket socket = serverSocket.accept();
        in = new DataInputStream(socket.getInputStream());
        out = new DataOutputStream(socket.getOutputStream());
        while (true) {
          String returnMSG = in.readUTF();
          System.out.println(returnMSG);
          Platform.runLater(() -> {
            taClient.appendText("C: " + returnMSG + '\n');
          });
        }
      } catch(IOException ex) {
        System.err.println(ex);
      }
    }).start();
  }

  public static void main(String[] args) {
    launch(args);
  }
}
